import react from "@vitejs/plugin-react";
import { defineConfig, type Plugin } from "vite";

// Builds straight into the Databricks App's static folder; app/main.py serves it as is.
// Dev: `npm run dev` proxies /api to a backend on :8000. `FAKE_API=1 npm run dev` answers
// /api/ask locally with canned results instead, since the real backend only runs on the cluster.
export default defineConfig({
  base: "./",
  plugins: [react(), ...(process.env.FAKE_API ? [fakeAsk()] : [])],
  build: { outDir: "../app/static", emptyOutDir: true },
  server: { proxy: { "/api": "http://localhost:8000" } },
});

// Route by words in the question:
//   "table"                 -> table (chart_type "Table")
//   "temperature"|"month"   -> two-series line chart
//   "predict"|"forecast"    -> rejected question
//   "offline"               -> HTTP 500 (network error path)
//   anything else           -> bar chart
function fakeAsk(): Plugin {
  return {
    name: "fake-ask",
    apply: "serve",
    configureServer(server) {
      server.middlewares.use("/api/reset", (_req, res) => {
        res.statusCode = 200;
        res.end();
      });
      server.middlewares.use("/api/ask", (req, res) => {
        let body = "";
        req.on("data", (c) => (body += c));
        req.on("end", () => {
          const { question = "" } = JSON.parse(body || "{}") as { question?: string };
          const q = question.toLowerCase();
          setTimeout(() => {
            if (q.includes("offline")) {
              res.statusCode = 500;
              res.end("backend unreachable");
              return;
            }
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify(pick(q, question)));
          }, 1800);
        });
      });
    },
  };
}

function pick(q: string, question: string) {
  if (q.includes("predict") || q.includes("forecast")) {
    return {
      reason: "The tables hold historical measurements only, so a forecast cannot be answered from them.",
      suggestion: "Average power per machine type for the last 30 days",
    };
  }
  if (q.includes("table")) {
    const columns = ["region", "quarter", "product", "revenue_eur", "units_sold"];
    const rows = [
      ["EMEA", "2026-Q1", "Lens assembly", 1240500.5, 312], ["EMEA", "2026-Q2", "Lens assembly", 1310200.0, 330],
      ["APAC", "2026-Q1", "Stage module", 980400.25, 201], ["APAC", "2026-Q2", "Stage module", 1022300.0, 214],
      ["AMER", "2026-Q1", "Light source", 2104000.0, 87], ["AMER", "2026-Q2", "Light source", 2210000.75, 91],
      ["EMEA", "2026-Q1", "Metrology kit", 410200.0, 540], ["APAC", "2026-Q2", "Metrology kit", 398100.0, 522],
    ].map((r) => Object.fromEntries(columns.map((c, i) => [c, r[i]])));
    return {
      title: question, table_name: "sales_and_marketing", rows,
      chart: { chart_type: "Table", encodings: {}, semantic_types: { region: "Category", quarter: "Category", product: "Category", revenue_eur: "Quantity", units_sold: "Count" } },
      findings: "Light source carries the largest revenue per unit, at over 20,000 euro each. Metrology kits sell the most units but bring the least revenue.",
    };
  }
  if (q.includes("temperature") || q.includes("month")) {
    const rows: Record<string, unknown>[] = [];
    for (let m = 1; m <= 12; m++) {
      const month = `2026-${String(m).padStart(2, "0")}-01`;
      rows.push({ month, city: "Veldhoven", avg_temp_c: +(3 + 15 * Math.sin(((m - 4) / 12) * Math.PI * 2) + 10).toFixed(1) });
      rows.push({ month, city: "Hwaseong", avg_temp_c: +(-2 + 18 * Math.sin(((m - 4) / 12) * Math.PI * 2) + 12).toFixed(1) });
    }
    return {
      title: question, table_name: "weather_eindhoven_amsterdam_2026", rows,
      chart: { chart_type: "Line Chart", encodings: { x: "month", y: "avg_temp_c", color: "city" }, semantic_types: { month: "Date", city: "Category", avg_temp_c: "Quantity" } },
      findings: "Hwaseong swings wider across the year, from below zero in winter to above 28 degrees in August. Veldhoven stays between 4 and 20 degrees.",
    };
  }
  const rows = [
    ["Veldhoven", 1240.5], ["Hwaseong", 1198.2], ["Hsinchu", 1175.9], ["Chandler", 1102.3], ["Hillsboro", 1088.7], ["Dresden", 1012.4],
  ].map(([location, avg_power_kw]) => ({ location, avg_power_kw }));
  return {
    title: question, table_name: "machine_metrics", rows,
    chart: { chart_type: "Bar Chart", encodings: { x: "location", y: "avg_power_kw" }, semantic_types: { location: "Category", avg_power_kw: "Quantity" } },
    findings: "Veldhoven draws the most power at 1,240 kW on average, about 22 percent above Dresden at the bottom. The six sites sit within a 230 kW band.",
  };
}
