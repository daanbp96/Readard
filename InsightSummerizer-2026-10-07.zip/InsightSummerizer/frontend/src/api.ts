// Contract with the backend: README.md, section "API".

export type CardId = "a" | "b" | "c";
export type Row = Record<string, unknown>;

export interface Chart {
  chart_type: string;
  encodings: Record<string, string>;
  semantic_types: Record<string, string>;
}

export interface Answer {
  title: string;
  table_name: string;
  rows: Row[];
  chart: Chart;
  findings: string;
}

export interface Rejection {
  reason: string;
  suggestion: string | null;
}

export type AskResponse = Answer | Rejection;

/** Throws on network failure. A rejected question is a 200 Rejection; a backend crash (proxy 500) becomes a Rejection with the detail. */
export async function ask(card_id: CardId, question: string): Promise<AskResponse> {
  const res = await fetch("/api/ask", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ card_id, question }),
  });
  if (res.ok) return res.json();
  const detail = (await res.json().catch(() => null))?.detail ?? `${res.status} ${res.statusText}`;
  return { reason: `The backend failed: ${detail}`, suggestion: null };
}
