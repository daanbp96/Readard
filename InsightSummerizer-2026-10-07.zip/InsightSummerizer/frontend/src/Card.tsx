import { useEffect, useRef, useState } from 'react'
import type { FormEvent, KeyboardEvent } from 'react'
import { ask } from './api'
import type { Answer, CardId, Rejection } from './api'
import { Chart } from './Chart'

interface Entry {
  question: string
  findings: string
}

export function Card({ id, size, onSelect }: { id: CardId; size: 'focus' | 'side'; onSelect: () => void }) {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<Answer | null>(null)
  const [thread, setThread] = useState<Entry[]>([])
  const [error, setError] = useState<Rejection | null>(null)
  const [input, setInput] = useState('')
  const textarea = useRef<HTMLTextAreaElement>(null)

  const status = loading ? 'loading' : error ? 'error' : result ? 'result' : 'empty'
  const side = size === 'side'

  // Grow the textarea with its content, up to the CSS max-height (3 lines).
  useEffect(() => {
    const el = textarea.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = `${el.scrollHeight}px`
  }, [input])

  async function send(text: string) {
    const question = text.trim()
    if (!question || loading) return
    setInput(question)
    setError(null)
    setLoading(true)
    try {
      const r = await ask(id, question)
      if ('reason' in r) {
        setError(r)
      } else {
        setResult(r)
        setThread((t) => [...t, { question, findings: r.findings }])
        setInput('')
      }
    } catch {
      setError({ reason: 'Could not reach the server.', suggestion: null })
    }
    setLoading(false)
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    send(input)
  }

  function onKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      send(input)
    }
  }

  const bandEmpty = status === 'empty' || (side && status === 'result')
  const bandClass = `band${bandEmpty ? ' band--empty' : ''}${status === 'error' ? ' band--error' : ''}`

  return (
    <section className={`card card--${size}`} aria-label={result?.title ?? 'New chart'}>
      <div className="card__head">
        {result && <h2 className="card__title">{result.title}</h2>}
        {result && <span className="chip">{result.table_name}</span>}
      </div>
      {side && (
        <button type="button" className="swap" onClick={onSelect} aria-label="Show as the main chart" title="Show as the main chart">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M2 5h10M9 2l3 3-3 3" />
            <path d="M14 11H4M7 8l-3 3 3 3" />
          </svg>
        </button>
      )}

      <div className={`chart${loading ? ' is-loading' : ''}${status === 'error' ? ' is-dim' : ''}`}>
        {result ? (
          <div className="chart__box">
            <Chart rows={result.rows} chart={result.chart} title={result.title} onError={(reason) => setError({ reason, suggestion: null })} />
          </div>
        ) : (
          !loading && (
            <div className="empty">
              <p>Nothing here yet.</p>
            </div>
          )
        )}
        {loading && <div className="skeleton" aria-hidden="true" />}
      </div>

      <div className={bandClass}>
        <div className="band__live" role="status" aria-live="polite" aria-atomic="true">
          {loading && <StatusLines table={result?.table_name} />}
          {status === 'result' && result && !side && <p>{result.findings}</p>}
          {status === 'error' && error && (
            <div role="alert">
              <p>
                <span className="why">
                  <Glyph /> Not answered.
                </span>{' '}
                {error.reason}
              </p>
              <div className="chips fix">
                {error.suggestion && (
                  <button type="button" onClick={() => send(error.suggestion!)}>
                    Try: {error.suggestion}
                  </button>
                )}
                <button type="button" onClick={() => send(input)}>
                  Try again
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {thread.length > 0 && !side && <Thread entries={thread} />}

      <form className="ask" onSubmit={onSubmit}>
        <textarea
          ref={textarea}
          rows={1}
          value={input}
          disabled={loading}
          autoFocus={id === 'a'}
          placeholder="Ask about this chart, or start something new"
          aria-label="Ask about this chart"
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={onKeyDown}
        />
        <button className="send" type="submit" disabled={loading}>
          Ask
        </button>
      </form>
    </section>
  )
}

const STEPS = ['Writing the query', 'Choosing a chart']

function StatusLines({ table }: { table?: string }) {
  const lines = [`Reading ${table ?? 'the tables'}`, ...STEPS]
  const [i, setI] = useState(0)
  const [fading, setFading] = useState(false)

  useEffect(() => {
    let swap: ReturnType<typeof setTimeout> | undefined
    const tick = setInterval(() => {
      setFading(true)
      swap = setTimeout(() => {
        setI((n) => (n + 1) % lines.length)
        setFading(false)
      }, 150)
    }, 1000)
    return () => {
      clearInterval(tick)
      clearTimeout(swap)
    }
  }, [lines.length])

  return <p className={`status${fading ? ' is-fading' : ''}`}>{lines[i]}</p>
}

const VISIBLE = 6

function Thread({ entries }: { entries: Entry[] }) {
  const [all, setAll] = useState(false)
  const box = useRef<HTMLDivElement>(null)
  const hidden = all ? 0 : Math.max(0, entries.length - VISIBLE)

  useEffect(() => {
    const el = box.current
    if (el) el.scrollTop = el.scrollHeight
  }, [entries.length])

  return (
    <div className="thread" ref={box}>
      <ol>
        {hidden > 0 && (
          <li className="count-row">
            <button type="button" className="textbtn" onClick={() => setAll(true)}>
              {hidden} earlier {hidden === 1 ? 'question' : 'questions'}
            </button>
          </li>
        )}
        {entries.slice(hidden).map((e, i) => {
          const n = hidden + i + 1
          const current = n === entries.length
          return (
            <li key={n} className={current ? 'is-current' : ''}>
              <span className="n">{n}</span>
              {current || !e.findings ? (
                <span className="q">{e.question}</span>
              ) : (
                <details className="q">
                  <summary>{e.question}</summary>
                  <p>{e.findings}</p>
                </details>
              )}
            </li>
          )
        })}
      </ol>
    </div>
  )
}

function Glyph() {
  return (
    <svg aria-hidden="true" width="14" height="14" viewBox="0 0 16 16">
      <circle cx="8" cy="8" r="6.75" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <path d="M8 4.5v4.5M8 11.5v.2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  )
}
