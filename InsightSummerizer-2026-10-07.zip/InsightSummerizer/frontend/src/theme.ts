// House theme for Flint.
import type { ThemeSpec } from 'flint-chart'

const sans = "'IBM Plex Sans', system-ui, sans-serif"

export const houseTheme = {
  id: 'insum',
  label: 'Insum',

  ink: {
    surface: { source: 'house', canvas: '#ffffff', plot: '#ffffff' },
    text: { primary: '#15192b', secondary: '#5b6275', muted: '#8a90a3' },
    structure: { grid: '#e1e4ea', axis: '#e1e4ea', rule: '#e1e4ea', frame: '#e1e4ea', connector: '#e1e4ea' },
    series: {
      single: '#1d4ed8',
      categorical: ['#1d4ed8', '#eb6834', '#1baf7a', '#eda100'],
      // A fifth series folds into "Other".
      overflow: '#8a90a3',
      sequential: { stops: ['#e8eefc', '#1d4ed8'], space: 'lab', endpointsAgainstSurface: true },
      diverging: { stops: ['#eb6834', '#ffffff', '#1d4ed8'], neutral: '#ffffff', space: 'lab' },
      status: { positive: '#1baf7a', negative: '#c2341f', neutral: '#8a90a3' },
    },
    accent: '#1d4ed8',
  },

  type: {
    minSize: 12,
    headline: { family: sans, size: 15, weight: 'semibold', color: '#15192b', case: 'asIs' },
    deck: { family: sans, size: 13, weight: 'regular', color: '#5b6275', case: 'asIs' },
    axisLabel: { family: sans, size: 12, weight: 'regular', color: '#8a90a3', case: 'asIs' },
    axisTitle: { family: sans, size: 12, weight: 'regular', color: '#5b6275', case: 'asIs' },
    valueLabel: { family: sans, size: 12, weight: 'regular', color: '#5b6275', case: 'asIs' },
    keyLabel: { family: sans, size: 12, weight: 'regular', color: '#5b6275', case: 'asIs' },
    annotation: { family: sans, size: 12, weight: 'regular', color: '#5b6275', case: 'asIs' },
  },

  structure: {
    axis: {
      categorical: { line: 'full', lineWeight: 1, ticks: 'omit', labelGap: 8 },
      measure: { line: 'omit', ticks: 'omit', labelGap: 8, tickDensity: 'sparse' },
    },
    // 'full' presence keeps the exact hairline color; 'quiet'/'hairline' lighten it.
    grid: { measure: 'full', category: 'omit', style: 'solid', weight: 1, zero: 'omit' },
    frame: 'omit',
    baseline: 'full',
  },

  marks: {
    cornerRadius: 4,
    bandFraction: 0.7,
    strokeWeight: 2,
    strokeCap: 'round',
    strokeJoin: 'round',
    interpolation: 'linear',
    // size is area: 64 is an 8px marker.
    point: { presence: 'omit', size: 64, fill: 'solid', halo: { presence: 'full', width: 2 } },
    outline: { presence: 'omit' },
    separator: { presence: 'hairline', source: 'surface', width: 1 },
    slice: { gap: 2, gapStyle: 'rule' },
  },

  geometry: {
    line: { width: 2, cap: 'round', join: 'round', interpolation: 'linear' },
    point: { presence: 'omit', size: 64, vertexSize: 64, fill: 'solid', outlineWidth: 2 },
    band: { fraction: 0.7, cornerRadius: 4, outline: 'omit' },
  },

  labels: { truncation: 'never', angle: 'horizontal' },

  legend: {
    // Single series: Flint draws no legend without a multi-valued series field.
    // Multi series: a compact row under the x axis. Inside overlapped tall bars and pie slices, top collided with the y-axis title.
    placement: ['bottom'],
    direction: 'horizontal',
    title: 'omit',
    suppressWhenAxisNames: true,
  },

  dataLabels: { show: 'never', inkMode: 'fixed' },
  annotation: {
    axisTitles: 'whenAmbiguous',
    axisTitlePlacement: 'rotated', // flatAboveAxis made Flint reserve a 54px empty band above the plot
    unit: 'lastTick',
    numberFormat: { precision: 'auto', thousands: 'separator' },
    pointEmphasis: 'endpoints',
    pointLabels: 'endpoints',
  },

  layout: {
    density: 'compact',
    bandStep: 24,
    bandStepFit: 1,
    titleBlock: { anchor: 'start', gap: 'tight' },
  },

  compileDefaults: { addTooltips: true },

  variants: [
    {
      when: { seriesCount: { gte: 2 } },
      then: { annotation: { pointLabels: 'never' } },
      because: 'Flint prints one value per series end with no collision check; two close series overprint. The legend and tooltip carry the values.',
    },
  ],
} satisfies ThemeSpec
