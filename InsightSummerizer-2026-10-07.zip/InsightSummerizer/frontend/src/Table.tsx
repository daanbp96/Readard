import type { Row } from './api'

const numberFormat = new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 })

function cell(value: unknown): { text: string; numeric: boolean } {
  if (value === null || value === undefined) return { text: '', numeric: false }
  if (typeof value === 'number') return { text: numberFormat.format(value), numeric: true }
  return { text: String(value), numeric: false }
}

export function Table({ rows }: { rows: Row[] }) {
  const columns = Object.keys(rows[0] ?? {})
  return (
    <div className="data-table-wrap">
      <table className="data-table">
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c} scope="col" className={typeof rows[0]?.[c] === 'number' ? 'num' : undefined}>
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i}>
              {columns.map((c) => {
                const { text, numeric } = cell(row[c])
                return (
                  <td key={c} className={numeric ? 'num' : undefined}>
                    {text}
                  </td>
                )
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
