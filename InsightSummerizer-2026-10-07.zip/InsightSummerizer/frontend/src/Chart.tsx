import { useEffect, useRef, useState } from 'react'
import embed from 'vega-embed'
import { assembleVegaLite } from 'flint-chart/vegalite'
import type { Chart, Row } from './api'
import { houseTheme } from './theme'
import { Table } from './Table'

interface Size {
  width: number
  height: number
}

/**
 * Flint sizes the plot from baseSize and emits `width: { step }` for banded
 * axes. We want the whole graphic (axes, labels, padding) to fill the
 * container, so the top-level size is set to the container pixels and
 * Vega's fit autosize shrinks the plot area to make everything fit.
 * Composed specs (facet/concat) do not accept a top-level size; left as is.
 */
function fillContainer(spec: Record<string, unknown>, size: Size) {
  if (spec.facet || spec.hconcat || spec.vconcat || spec.concat) return
  spec.width = size.width
  spec.height = size.height
  spec.autosize = { type: 'fit', contains: 'padding' }
}

export function Chart({ rows, chart, title, onError }: { rows: Row[]; chart: Chart; title: string; onError: (reason: string) => void }) {
  const rootRef = useRef<HTMLDivElement>(null)
  const [size, setSize] = useState<Size | null>(null)
  const columns = Object.keys(rows[0] ?? {})

  useEffect(() => {
    const el = rootRef.current
    if (!el) return
    let timer: number | undefined
    let first = true
    const ro = new ResizeObserver((entries) => {
      const { width, height } = entries[0].contentRect
      const next = { width: Math.floor(width), height: Math.floor(height) }
      if (first) {
        first = false
        setSize(next)
        return
      }
      window.clearTimeout(timer)
      timer = window.setTimeout(() => setSize(next), 100)
    })
    ro.observe(el)
    return () => {
      window.clearTimeout(timer)
      ro.disconnect()
    }
  }, [])

  const showTable = chart.chart_type === 'Table'

  useEffect(() => {
    const root = rootRef.current
    if (!root || showTable || !size || size.width <= 0 || size.height <= 0) return
    let cancelled = false
    let finalize: (() => void) | undefined
    const view = document.createElement('div')
    view.className = 'chart-view chart-view-enter'

    ;(async () => {
      try {
        const spec = assembleVegaLite({
          data: { values: rows },
          semantic_types: chart.semantic_types,
          chart_spec: {
            chartType: chart.chart_type,
            encodings: chart.encodings,
            baseSize: { width: size.width, height: size.height },
            canvasSize: { width: size.width, height: size.height },
          },
          theme_spec: houseTheme,
          field_display_names: Object.fromEntries(columns.map((c) => [c, c.replace(/_/g, ' ')])), // axis titles read as words
        }) as Record<string, unknown>
        for (const k of Object.keys(spec)) if (k.startsWith('_')) delete spec[k] // Flint's private bookkeeping, dead weight for Vega
        fillContainer(spec, size)
        spec.description = title
        root.appendChild(view)
        const result = await embed(view, spec as Parameters<typeof embed>[1], {
          renderer: 'svg',
          actions: false,
        })
        if (cancelled) {
          result.finalize()
          view.remove()
          return
        }
        finalize = result.finalize
        for (const old of Array.from(root.children)) if (old !== view) old.remove()
        requestAnimationFrame(() => view.classList.remove('chart-view-enter'))
      } catch (err) {
        view.remove()
        if (!cancelled) onError(`The chart could not be drawn: ${err instanceof Error ? err.message : String(err)}`)
      }
    })()

    return () => {
      cancelled = true
      finalize?.()
    }
  }, [rows, chart, size, title, showTable, onError])

  useEffect(() => {
    if (!showTable) return
    const root = rootRef.current
    if (!root) return
    for (const old of Array.from(root.querySelectorAll('.chart-view'))) old.remove()
  }, [showTable])

  return (
    <div
      ref={rootRef}
      className="chart-root"
      role={showTable ? undefined : 'img'}
      aria-label={showTable ? undefined : title}
    >
      {showTable ? <Table rows={rows} /> : null}
    </div>
  )
}
