import { useEffect, useState } from 'react'
import type { CardId } from './api'
import { Card } from './Card'

const cardIds: CardId[] = ['a', 'b', 'c']

export default function App() {
  // order[0] is the focus slot. Keys keep each card's state when slots swap.
  const [order, setOrder] = useState(cardIds)
  const swap = (id: CardId) => setOrder(order.map((x) => (x === id ? order[0] : x === order[0] ? id : x)))

  // A page reload starts every card clean server-side. Fire and forget.
  useEffect(() => {
    for (const card_id of cardIds) {
      fetch(`/api/reset/${card_id}`, { method: 'POST' }).catch(() => {})
    }
  }, [])

  return (
    <>
      <header className="topbar">
        <span className="wordmark">InsightSummarizer</span>
        <span className="asml">ASML</span>
      </header>
      <main className="stage">
        {order.map((id, i) => (
          <Card key={id} id={id} size={i === 0 ? 'focus' : 'side'} onSelect={() => swap(id)} />
        ))}
      </main>
    </>
  )
}
