import os

from databricks.sdk import WorkspaceClient
from databricks.sdk.core import Config
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles


def create_app() -> FastAPI:
    cluster_id = os.environ["CLUSTER_ID"]
    backend_port = os.environ["BACKEND_PORT"]

    client = WorkspaceClient(config=Config(http_timeout_seconds=120, retry_timeout_seconds=1))
    base = f"/driver-proxy-api/o/{client.get_workspace_id()}/{cluster_id}/{backend_port}/api/"
    headers = {"Content-Type": "application/json", "Accept": "application/json"}

    app = FastAPI(title="InsightSummarizer", openapi_url=None)

    @app.post("/api/{path:path}")
    def post(path: str, body: dict) -> dict:
        try:
            return client.api_client.do("POST", base + path, body=body, headers=headers)
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"{type(exc).__name__}: {exc}") from exc

    app.mount("/", StaticFiles(directory="static", html=True))

    return app
