# Databricks notebook source
# MAGIC %md
# MAGIC # InsightSummarizer backend
# MAGIC Serves the backend on port 8000 until the cell is interrupted. Run `write_tables` first to create the tables.

# COMMAND ----------

from backend.api import serve

# COMMAND ----------

serve(spark, dbutils)
