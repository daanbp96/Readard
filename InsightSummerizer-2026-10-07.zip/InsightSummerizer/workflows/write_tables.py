# Databricks notebook source
# MAGIC %md
# MAGIC # InsightSummarizer tables
# MAGIC Rebuilds the three Delta tables from the CSVs on the volume. Overwrites existing tables.

# COMMAND ----------

from config.tables import TABLES
from etl.write_tables import write_table

# COMMAND ----------

for table in TABLES.values():
    write_table(spark, table)
