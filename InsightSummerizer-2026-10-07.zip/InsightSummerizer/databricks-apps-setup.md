# Databricks Apps: setup learnings

General notes for standing up a new Databricks App. Not project-specific.

## Egress

**Serverless cannot reach a private LLM endpoint. A classic cluster can.** The app runtime and
serverless compute both sit outside the workspace VNet, so neither can call an Azure OpenAI resource
behind a private endpoint. Every LLM call has to originate on a VNet-injected classic cluster, this
is also why the same notebook works on a cluster and fails on serverless.

Settle this before anything else, because it decides whether the app needs a cluster at all, and a
cluster is the one thing app resources cannot grant. An app that must reach a private endpoint is
always two-tier: the app serves the UI and proxies, the cluster holds the client. The identity
questions below all follow from that, not the other way round.

## Identity

**An app gets its own service principal, and it has nothing.** Databricks Apps auto-creates a
workspace-local SP named `app-<slug> <appname>` at first deploy. Two consequences:

- It is **not** in Entra. Platform-provisioned SPs resolve via `az ad sp show`; an app SP returns
  "does not exist". Anywhere that expects an Entra SP (IDP registration, "bring your own service
  principal", Azure RBAC) cannot take it.
- It starts with zero permissions on anything outside the app. Every cluster, scope, table and
  endpoint it touches is a separate grant.

**Plan the identity before deploying, not after.** Which identity the app runs as determines whether
you need an admin. Everything else is self-serve.

## Which identity to use

Ranked, best first:

1. **A platform/workload SP that already holds the grants.** Entra-backed, provisioned by the
   platform team, already on the clusters and scopes. Nothing to request.
2. **The app's own SP**, only if everything it touches is grantable by you.
3. **A personal PAT.** Works, but the app acts as *you* for every user who opens it, and dies when
   the token expires. Fine to unblock a demo, not to run anything.

**User authorization (OBO) cannot reach compute.** The full scope list is SQL, Genie, Postgres,
model serving, UC catalogs/schemas/tables/connections, files, AI gateway, vector search, workspace
folders, MCP. There is no clusters or compute scope. OBO suits an app that queries SQL/UC/vector
search directly; it is useless for one that talks to a process on a cluster.

## Forcing the identity

The trap: inside an app the runtime injects the app SP's OAuth credentials, and the SDK's default
chain tries `oauth_service_principal` **before** `azure_service_principal`. Adding Azure SP
credentials to the environment does nothing on its own, the app SP silently keeps winning.

Set the auth type explicitly in `app.yaml`:

```yaml
env:
  - name: DATABRICKS_AUTH_TYPE
    value: "azure-client-secret"
  - name: ARM_TENANT_ID
    value: "<tenant>"
  - name: ARM_CLIENT_ID
    valueFrom: "sp-client-id"
  - name: ARM_CLIENT_SECRET
    valueFrom: "sp-client-secret"
```

With `DATABRICKS_AUTH_TYPE` set the chain skips every other provider. No code change is needed as
long as the client is constructed without explicit credentials, since the SDK reads all of this from
the environment.

## Permissions you will hit

| To do this | You need | Self-serve? |
|---|---|---|
| Bind a secret as an app resource | MANAGE on the **scope**, not read | No, unless you own the scope |
| Let the app reach a cluster | CAN_ATTACH_TO on the cluster | No, needs admin |
| Create a secret scope | nothing, creator becomes manager | Yes |

**The secret-scope wall has a way around it.** You cannot bind a platform-owned scope you only have
read on. You can create your own scope (creator becomes manager), copy the values in, and bind that.
Costs a duplicated credential, a real tradeoff, make it deliberately.

**The cluster wall does not.** Cluster ACLs need MANAGE, and app resources have no cluster type, so a
cluster grant is always out-of-band from the bundle. If the app needs a cluster, queue that grant on
day one.

Cluster permissions are a ladder: `CAN_ATTACH_TO` < `CAN_RESTART` < `CAN_MANAGE`, each including the
ones below. An identity that already has CAN_RESTART needs nothing added, check before raising a
request. (Documented behaviour, not independently tested.)

## Diagnosing

Two errors that look similar and mean opposite things:

- **403 PERMISSION_DENIED** → identity problem. The request never reached your service.
- **502 Bad Gateway** → identity is fine, nothing is listening. Progress.
- **400 INVALID_STATE: Cluster ... is in Pending/Terminated state** → identity is fine too. The proxy
  authenticated you and answered about the cluster. Start the cluster and try again.

Anything that is not a 403 is an identity that works. That makes the first proxy call worth doing
before the backend exists: it separates the identity half from the application half, and only one of
them is slow to fix.

**Test an identity before wiring it up.** Put its credentials in the environment and call the target
endpoint directly with `databricks api post <path>`. Ten seconds, and it says whether the plan is
viable before you touch a bundle. Highest-value habit here.

The SDK wraps *any* non-JSON error body in "this is likely a bug in the SDK, please report", 400s
and 403s alike. It almost never is. The real status and message sit in the request log underneath;
read that and ignore the wrapper.

## Deployment mechanics

- `bundle validate` → `deploy` → `run`. Validate checks schema only. It passes happily with
  placeholder env values and says nothing about whether the runtime identity works.
- `app.yaml` `valueFrom:` references a resource `name:` declared in `databricks.yml`. Secrets are
  declared in the bundle, consumed by name in the app config.
- Bundles deploy to `/Workspace/Users/<you>/.bundle/...` by default, tying the deployment to your
  account. Set `workspace.root_path` if anyone else needs to redeploy.
- `bundle run` sometimes drops its status-polling connection and prints a network error. The
  deployment usually continues server-side. Check `apps get` before re-running.
- Keep the app's `requirements.txt` to what the app process itself imports. A thin proxy or UI server
  needs four or five packages. Heavy dependencies belong on the compute, not the app runtime.

## Setup order

1. List what the app must reach: clusters, scopes, warehouses, endpoints. Anything behind a private
   endpoint means a classic cluster and a two-tier app, check this first, it sets the shape.
2. Pick the identity. If anything on that list is a cluster, check for an existing workload SP with
   CAN_RESTART.
3. Test that identity against each target with `databricks api` before writing any config.
4. Request whatever it fails on. Cluster grants are the long pole, raise them first.
5. Only then build the bundle.

Steps 3 and 4 are the ones worth not skipping. Doing them last turns a one-hour setup into a
multi-day one.
