from dataclasses import dataclass

from config.settings import PATHS


@dataclass(frozen=True)
class Column:
    name: str
    type: str
    meaning: str


@dataclass(frozen=True)
class Table:
    name: str
    description: str
    csv: str
    columns: tuple[Column, ...]

    @property
    def full_name(self) -> str:
        return f"{PATHS.tables}.{self.name}"

    @property
    def text(self) -> str:
        lines = [f"Table: {self.name}", f"Description: {self.description}", "Columns:"]
        lines += [f"- {c.name} ({c.type}): {c.meaning}" for c in self.columns]
        return "\n".join(lines)


def catalog(tables: dict[str, Table]) -> str:
    return "\n\n".join(t.text for t in tables.values())


TABLES: dict[str, Table] = {t.name: t for t in (
    Table(
        name="machine_metrics",
        description="Synthetic semiconductor equipment performance per machine, location and month",
        csv="Machine_Metrics.csv",
        columns=(
            Column("machine_type", "string", "Equipment family, for example EUV or DUV"),
            Column("location", "string", "Fab site where the machine runs"),
            Column("month", "timestamp", "Reporting month"),
            Column("status", "string", "Operational status in the month"),
            Column("uptime_pct", "double", "Share of the month the machine was available, in percent"),
            Column("power_consumption_kw", "double", "Average power draw in kilowatts"),
            Column("wafers_processed", "bigint", "Number of wafers processed in the month"),
            Column("error_count", "bigint", "Number of errors logged in the month"),
        ),
    ),
    Table(
        name="sales_and_marketing",
        description="Synthetic retail store performance with sales metrics and BCG segments",
        csv="Sales_And_Marketing.csv",
        columns=(
            Column("store_id", "bigint", "Store identifier"),
            Column("store_name", "string", "Store name"),
            Column("store_type", "string", "Store format, for example flagship or outlet"),
            Column("region", "string", "Sales region"),
            Column("bcg_segment", "string", "BCG matrix segment: star, cash cow, question mark or dog"),
            Column("class_sales", "string", "Sales class of the store"),
        ),
    ),
    Table(
        name="weather_eindhoven_amsterdam_2026",
        description="Daily average temperature for Amsterdam and Eindhoven in 2026",
        csv="weather_eindhoven_amsterdam_2026.csv",
        columns=(
            Column("date", "timestamp", "Calendar day"),
            Column("city", "string", "Amsterdam or Eindhoven"),
            Column("avg_temp", "double", "Daily average temperature in degrees Celsius"),
        ),
    ),
)}
