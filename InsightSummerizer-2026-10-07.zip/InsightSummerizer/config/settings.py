from dataclasses import dataclass


@dataclass(frozen=True)
class AzureOpenAI:
    endpoint: str = "https://idp-insum-dev-oai.openai.azure.com/"
    api_version: str = "2025-04-01-preview"
    model: str = "gpt-4.1"
    tenant_id: str = "af73baa8-f594-4eb2-a39d-93e96cad61fc"
    token_scope: str = "https://cognitiveservices.azure.com/.default"
    secret_scope: str = "idp-insum-dev-kv"
    client_id_key: str = "idp-insum-dev-sp-AppID"
    client_secret_key: str = "idp-insum-dev-sp-ClientSecret"


@dataclass(frozen=True)
class Paths:
    csvs: str = "/Volumes/idp_adap_dev/idp_insum/insum"
    tables: str = "idp_adap_dev.idp_insum"


@dataclass(frozen=True)
class Server:
    host: str = "0.0.0.0"
    port: int = 8000


AZURE = AzureOpenAI()
PATHS = Paths()
SERVER = Server()
