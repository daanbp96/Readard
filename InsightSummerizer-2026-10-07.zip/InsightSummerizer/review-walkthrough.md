# Review walkthrough: the POST /api/{path} flow

Working note for a hop-by-hop code review. Not a design record (that is README.md).

## How we work

- Follow one request from the browser to Azure OpenAI and back, one file per hop.
- Each hop: show the code, list what is unclean or inefficient, discuss, then "next".
- Lens: clean and efficient for what exists today. No findings about hypothetical
  future routes, hardening, failure modes, or load. Only: dead code, duplication,
  something stdlib or an installed dependency already does, a shorter equivalent.
- Demo scope, three users with access. Decide routine things and apply them directly.

## Resume prompt

> Continue the review walkthrough in review-walkthrough.md from the next unchecked hop.
> Same lens, same format: code, findings, discuss, next.

## Hops

- [x] 1. `app/main.py` catch-all POST route, forwards over the cluster driver-proxy
- [x] 2. `backend/api.py` + `workflows/backend.py` receiving server, two routes
- [x] 3. `backend/orchestrator.py` one turn, in-memory card state
- [ ] 4. `backend/steps/interpret_question.py`
- [ ] 5. `backend/steps/write_sql.py`
- [ ] 6. `backend/steps/run_sql.py`
- [ ] 7. `backend/steps/build_chart.py`
- [ ] 8. `backend/steps/summarise_result.py`
- [ ] 9. `backend/llm.py` LLM object (client plus deployment), parse() and text(); create_llm()
- [ ] 10. `frontend/src/api.ts` how the response lands in the browser

Skipped: `app/app.yaml` (config only, no request passes through it).

## Decisions so far

- Hop 1: deleted the unused `/api/health` route from `app/main.py`, `backend/api.py`
  and README. Inlined `forward` into the POST route since it had one caller left.
- Hop 2: nothing to change. Port duplicated in `config/settings.py` and `app/app.yaml`
  is accepted (different machines). Open thread: six positional args into
  `orchestrator.ask`, judge at hop 3.
  Follow-up: no `backend/schema.py`. `create_app` in `backend/api.py` sets the session schema with `USE`. `config/tables.py` declares `Table` and `Column` dataclasses (types written by hand);
  `Table.text` renders the LLM text. `dataset_cards` and the `cards_text` argument are
  gone; interpret gets the same table text (`catalog()`) as the SQL step. Sample rows and allowed values dropped.
  `etl/write_tables.py` takes a `Table`.
- Hop 3: module-level `cards` dict and the five-argument `ask` replaced by an `Orchestrator` class
  holding spark, llm, tables and the cards; `api.py` builds one at startup. `answer` dispatches with a
  `match` on the intent and `_query` / `_restyle` helpers; `CardState` lives in `backend/card.py`; a reject
  returns `{reason, suggestion}` and real failures propagate; the chart models are `ChartSpec` and
  `ChartSettings`.
