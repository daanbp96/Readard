import re
from pathlib import Path

import pandas as pd

from config.settings import PATHS
from config.tables import Table


def write_table(spark, table: Table) -> None:
    pdf = pd.read_csv(Path(PATHS.csvs) / table.csv)
    pdf.columns = [re.sub(r"[^a-zA-Z0-9]+", "_", c).lower().strip("_") for c in pdf.columns]
    for column in table.columns:
        if column.type == "timestamp":
            pdf[column.name] = pd.to_datetime(pdf[column.name], format="ISO8601")
    spark.createDataFrame(pdf).write.format("delta").mode("overwrite").saveAsTable(table.full_name)
