# InsightSummarizer

One screen with three chart cards. Type a business question into a card and get a chart (or a table), a title,
the table it came from, and two or three sentences on what the data shows. Follow-up questions on the same
card refine its chart. Questions that cannot be answered get a reason and a suggested question instead.

Built for an internal ASML demo on Databricks with Azure OpenAI behind a private endpoint. Python backend,
TypeScript frontend, no text-to-SQL or charting product in the loop.

## How a turn works

Each `/api/ask` calls `Orchestrator.answer` in `backend/orchestrator.py`, which runs five steps:

1. `interpret_question` (LLM): returns a `New`, `FollowUp` or `Reject`. New and FollowUp name the table
   and rewrite the question so it stands alone. A follow-up that only changes presentation (chart type,
   sort order) has `needs_data: false`; its settings are written into the card's chart spec and rows, so they
   persist across later follow-ups. A top-N is a data question and goes through SQL. A reject carries a reason and a suggested question and is returned as the answer.
2. `write_sql` (LLM): one SELECT on the chosen table plus a `ChartSpec` (type, x, y, color). For a follow-up
   it sees the card's previous SQL.
3. `run_sql` (code): wraps the query in `LIMIT ROW_LIMIT + 1` (`ROW_LIMIT` is 100), runs it on Spark, converts to
   plain JSON rows. More than `ROW_LIMIT` rows sets `truncated`. A query that fails propagates.
4. `build_chart` (code): a pure function of the card's `ChartSpec` and rows, run once per answer. Maps Spark types
   to Flint semantic types (Date, Quantity, Category, Percentage, Count, Year) and emits a `Chart` (chart_type,
   encodings, semantic_types). A `ChartSpec` of type table, an empty result, or a spec naming a column that
   does not exist all give `chart_type: "Table"` with empty encodings, and the card shows the table.
5. `summarise_result` (LLM): two or three sentences on what the rows show.

Card memory (`CardState` in `backend/card.py`: table_name, last five questions, last SQL, last rows, last chart)
is held per card id by the `Orchestrator` instance created once at startup. It is lost when the backend restarts and cleared by `/api/reset/{card_id}`, which the UI calls on page load.

Charts are compiled in the browser: the backend sends `{chart_type, encodings, semantic_types}`, the frontend
calls `assembleVegaLite` from `flint-chart` with the house theme in `frontend/src/theme.ts` and renders the
result with vega-embed. A compile or render error shows in the card's error band, like a rejection.

## API

```
POST /api/ask    { card_id: "a"|"b"|"c", question }
POST /api/reset/{card_id}
```

`/api/ask` answers 200 with one of two shapes:

```
Answer:    { title, table_name, rows (list of dicts), chart: { chart_type, encodings, semantic_types }, findings }
Rejection: { reason, suggestion }
```

The frontend tells them apart by the presence of `reason` and keeps the previous chart on a rejection.
Backend failures (a table name that does not exist, SQL that fails, a failed LLM call) are not
caught and surface as HTTP 500. `/api/reset/{card_id}` returns an empty body.

## UI

Three cards: one focus card (large) and two side cards. Only the focus card shows the findings band and the
question thread. Each side card has a swap button that trades places with the focus card; the card's chart and
thread move with it.

## Repo layout

```
config/
  settings.py        AZURE (endpoint, model, tenant, secret names), PATHS (csvs volume, tables schema), SERVER (host, port)
  tables.py          Table and Column dataclasses: name, description, csv, columns with type and meaning; `.text` renders the LLM text, `catalog()` joins all tables
etl/write_tables.py  takes a Table: csv on the volume -> clean column names -> declared timestamp columns parsed -> Delta
backend/
  api.py             FastAPI app (/api/ask, /api/reset/{card_id}), sets the session schema at startup, uvicorn runner
  orchestrator.py    Orchestrator.answer dispatches on the intent; Answer and Rejection response models
  card.py            CardState, what a card remembers between questions
  llm.py             LLM: one Azure OpenAI deployment with parse() (a model or a union of models) and text(); create_llm() builds it with mlflow autolog
  steps/             interpret_question, write_sql, run_sql (Result), build_chart (Chart), summarise_result
frontend/            Vite + React + TypeScript + flint-chart + vega-embed, builds into app/static
app/                 Databricks App: app.yaml, proxy main.py, serves app/static
workflows/write_tables.py  notebook: rebuild the three Delta tables from the CSVs on the volume
workflows/backend.py notebook: serve the backend
databricks.yml       bundle that deploys app/
```

## Data

Three synthetic datasets as Delta tables in `idp_adap_dev.idp_insum`: `machine_metrics`,
`sales_and_marketing`, `weather_eindhoven_amsterdam_2026`. `etl/write_tables.py` expects
`<PATHS.csvs>/<Table.csv>` on the Unity Catalog volume set in `config/settings.py` and overwrites each table from it.

At startup the backend runs `USE idp_adap_dev.idp_insum`, so generated SQL uses the short table name. Column types and meanings are declared in `config/tables.py`; each `Table` renders its own
prompt text.

## Run

1. Install `cluster-libraries.txt` as cluster libraries on `idp-insum-dev-dbcl-shared`.
2. Open `workflows/write_tables.py` as a notebook on that cluster and run it once to create the tables.
3. Open `workflows/backend.py` as a notebook on that cluster and run all cells. It keeps serving the backend
   on port 8000 while the last cell runs.
4. Build the UI: `cd frontend && npm install && npm run build`. Output lands in `app/static`, which is committed.
5. Deploy the app: `databricks bundle deploy -p adap-dev && databricks bundle run insum_demo -p adap-dev`.

Local UI only: `cd frontend && FAKE_API=1 npm run dev` answers `/api/ask` with canned results (see the comment
in `frontend/vite.config.ts` for the keywords). Without `FAKE_API`, the dev server proxies `/api` to
`localhost:8000`.

## Configuration

| Setting | Value | Where |
|---|---|---|
| LLM deployment | `gpt-4.1` | `config/settings.py` |
| Azure OpenAI endpoint | `https://idp-insum-dev-oai.openai.azure.com/`, API version `2025-04-01-preview` | `config/settings.py` |
| Secret scope and keys | `idp-insum-dev-kv`: `idp-insum-dev-sp-AppID`, `idp-insum-dev-sp-ClientSecret` | `config/settings.py` |
| Tables | `idp_adap_dev.idp_insum.<table name>` | `config/settings.py`, `config/tables.py` |
| Cluster id | `0923-151533-fm12iugi` | `app/app.yaml` |
| App identity secrets | scope `insum-app-sp`: `client-id`, `client-secret` | `databricks.yml` |

The backend runs on the classic cluster because only that cluster can reach the private Azure OpenAI endpoint.
The Databricks App serves the static files and proxies `/api/*` through the driver proxy. Identity and
permission notes are in `databricks-apps-setup.md`.
