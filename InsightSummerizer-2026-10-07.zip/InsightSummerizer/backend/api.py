import threading

import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel

from backend.llm import create_llm
from backend.orchestrator import Answer, Orchestrator, Rejection
from config.settings import PATHS, SERVER
from config.tables import TABLES


class AskRequest(BaseModel):
    card_id: str
    question: str


def create_app(spark, dbutils) -> FastAPI:
    spark.sql(f"USE {PATHS.tables}")
    orchestrator = Orchestrator(spark, create_llm(dbutils), TABLES)
    app = FastAPI(title="InsightSummarizer backend", openapi_url=None)

    @app.post("/api/ask")
    def ask(body: AskRequest) -> Answer | Rejection:
        return orchestrator.answer(body.card_id, body.question)

    @app.post("/api/reset/{card_id}")
    def reset(card_id: str) -> None:
        orchestrator.reset(card_id)

    return app


def serve(spark, dbutils) -> None:
    """Run uvicorn in a thread so the notebook cell can be interrupted cleanly."""
    server = uvicorn.Server(uvicorn.Config(create_app(spark, dbutils), host=SERVER.host, port=SERVER.port, timeout_graceful_shutdown=5))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    try:
        thread.join()
    except KeyboardInterrupt:
        server.should_exit = True
        thread.join(timeout=10)
