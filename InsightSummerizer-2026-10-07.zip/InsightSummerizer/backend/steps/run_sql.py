import json

from pydantic import BaseModel

ROW_LIMIT = 100


class Result(BaseModel):
    spark_types: dict[str, str]
    rows: list[dict]
    truncated: bool


def run_sql(spark, sql: str) -> Result:
    df = spark.sql(f"SELECT * FROM ({sql.strip().rstrip(';')}) LIMIT {ROW_LIMIT + 1}")
    pdf = df.toPandas()
    truncated = len(pdf) > ROW_LIMIT
    pdf = pdf.head(ROW_LIMIT)
    rows = json.loads(pdf.to_json(orient="records", date_format="iso", default_handler=float))
    return Result(spark_types=dict(df.dtypes), rows=rows, truncated=truncated)
