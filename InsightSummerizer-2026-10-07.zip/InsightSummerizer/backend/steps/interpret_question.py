from typing import Literal

from pydantic import BaseModel

from backend.card import CardState
from backend.llm import LLM

SYSTEM_PROMPT = """You classify a user's question for a data dashboard card and rewrite it as a standalone question.

kind "new": the topic or table changes, or the card has no table yet. table_name is the exact name of the one table that answers the question.

kind "follow_up": the question only makes sense given the current chart on the card. table_name is the card's current table. needs_data is false only when the request is purely about presentation of the columns already shown: chart type or sort order. Anything that changes the data (a filter, a new measure, a new dimension, a different time range) sets needs_data to true.

kind "reject": no table covers the subject, a prediction or forecast is asked, or the question is too vague to name a measure and a dimension. reason is one short sentence. suggestion is one question that would work on these tables.

For new and follow_up, question is a standalone rewrite that is answerable with no conversation context, because the SQL step never sees the thread. Example: "Only EUV" asked after "average power per machine type" becomes "average power per machine type, EUV machines only".

For follow_up, settings is set only when the user explicitly asked for a chart type or a sort order. Otherwise settings is null. A field the user did not ask for is null.

Do not give a confidence score. Do not ask a clarifying question."""

USER_PROMPT = """Tables:
{catalog}

Current table on this card: {current_table}

Last questions on this card, newest last:
{history}

Last chart type on this card: {last_chart_type}

New question: {question}"""


class ChartSettings(BaseModel):
    type: Literal["bar", "line", "scatter", "pie", "table"] | None
    sort: Literal["asc", "desc"] | None


class Reject(BaseModel):
    kind: Literal["reject"]
    reason: str
    suggestion: str


class New(BaseModel):
    kind: Literal["new"]
    table_name: str
    question: str


class FollowUp(BaseModel):
    kind: Literal["follow_up"]
    table_name: str
    question: str
    needs_data: bool
    settings: ChartSettings | None


Intent = Reject | New | FollowUp


def interpret_question(llm: LLM, catalog: str, card: CardState, question: str) -> Intent:
    user_prompt = USER_PROMPT.format(
        catalog=catalog,
        current_table=card.table_name or "none",
        history="\n".join(card.history) or "none",
        last_chart_type=card.chart_type or "none",
        question=question,
    )
    return llm.parse(SYSTEM_PROMPT, user_prompt, Intent)
