from pydantic import BaseModel

from backend.steps.run_sql import Result
from backend.steps.write_sql import ChartSpec

NUMERIC = ("int", "bigint", "double", "float", "decimal", "long", "short")
NAMES = {"bar": "Bar Chart", "line": "Line Chart", "scatter": "Scatter Plot", "pie": "Pie Chart", "table": "Table"}


class Chart(BaseModel):
    chart_type: str
    encodings: dict[str, str]
    semantic_types: dict[str, str]


def semantic_type(name: str, spark_type: str) -> str:
    if spark_type.startswith(("date", "timestamp")):
        return "Date"
    if not any(n in spark_type for n in NUMERIC):
        return "Category"
    if "pct" in name or "percent" in name:
        return "Percentage"
    if name.startswith(("count_", "n_")):
        return "Count"
    if "int" in spark_type and (name == "year" or name.endswith("_year")):
        return "Year"
    return "Quantity"


def sort_rows(rows: list[dict], column: str, descending: bool) -> list[dict]:
    def value(row):
        return row[column] if row[column] is not None else float("-inf")
    return sorted(rows, key=value, reverse=descending)


def build_chart(spec: ChartSpec, result: Result) -> Chart:
    columns = result.spark_types
    semantic_types = {column: semantic_type(column, spark_type) for column, spark_type in columns.items()}
    columns_known = spec.x in columns and spec.y in columns and (spec.color is None or spec.color in columns)
    drawable = spec.type != "table" and result.rows and columns_known
    if not drawable:
        return Chart(chart_type=NAMES["table"], encodings={}, semantic_types=semantic_types)
    if spec.type == "pie":
        encodings = {"size": spec.y, "color": spec.x}
    else:
        encodings = {"x": spec.x, "y": spec.y}
        if spec.color:
            encodings["color"] = spec.color
    if spec.type == "bar" and spec.color:
        chart_type = "Stacked Bar Chart"
    else:
        chart_type = NAMES[spec.type]
    return Chart(chart_type=chart_type, encodings=encodings, semantic_types=semantic_types)

