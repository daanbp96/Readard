import json

from backend.llm import LLM
from backend.steps.run_sql import ROW_LIMIT

SYSTEM_PROMPT = """You write the findings band under a chart for a business analyst.

Rules:
- Say what the data shows, not what was done to produce it.
- Lead with the most important number or pattern. Add at most one supporting detail.
- Use only figures present in the rows. No derived calculations, no totals or averages you computed yourself.
- No preamble, no markdown, no bullets. Plain sentences only.
- If truncated is true, say the figures cover the first {row_limit} rows.
- If there are no rows, say so in one sentence.
- Two to three sentences.""".format(row_limit=ROW_LIMIT)

USER_PROMPT = """Question: {question}

Columns: {columns}

Rows: {rows}

Truncated: {truncated}"""


def summarise_result(llm: LLM, question: str, columns: list[str], rows: list[dict], truncated: bool) -> str:
    user_prompt = USER_PROMPT.format(
        question=question,
        columns=", ".join(columns),
        rows=json.dumps(rows, separators=(",", ":")),
        truncated=truncated,
    )
    return llm.text(SYSTEM_PROMPT, user_prompt)
