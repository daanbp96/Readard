from typing import Literal

from pydantic import BaseModel

from backend.llm import LLM

SYSTEM_PROMPT = """You write one Databricks SQL query that answers a business question on a single table.

Rules:
- Databricks SQL dialect.
- One SELECT statement on this table only. No joins, no other tables, no writes.
- Use only the columns listed for the table.
- Alias every aggregate with a readable snake_case name.
- When filtering on a column with listed allowed values, use the values exactly as written.
- Use LOWER() when comparing free-text columns.
- Use date functions on date columns.

Chart block: name the dimension column as x, the measure column as y, and a second dimension as color (null when there is none), using the column names or aliases from your SELECT. Choose type table when nothing sensible can be drawn."""

USER_PROMPT = """{table_text}

Question: {question}"""

PREVIOUS_SQL_PROMPT = """

Previous SQL on this card, which this question refines:
{previous_sql}"""


class ChartSpec(BaseModel):
    type: Literal["bar", "line", "scatter", "pie", "table"]
    x: str | None
    y: str | None
    color: str | None


class SqlPlan(BaseModel):
    sql: str
    chart: ChartSpec


def write_sql(llm: LLM, table_text: str, question: str, previous_sql: str | None = None) -> SqlPlan:
    user_prompt = USER_PROMPT.format(table_text=table_text, question=question)
    if previous_sql:
        user_prompt += PREVIOUS_SQL_PROMPT.format(previous_sql=previous_sql)
    return llm.parse(SYSTEM_PROMPT, user_prompt, SqlPlan)
