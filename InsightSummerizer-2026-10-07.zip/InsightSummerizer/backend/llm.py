import mlflow
from azure.identity import ClientSecretCredential, get_bearer_token_provider
from openai import AzureOpenAI
from pydantic import create_model

from config.settings import AZURE


def _messages(system_prompt: str, user_prompt: str) -> list[dict]:
    return [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]


class LLM:
    def __init__(self, client: AzureOpenAI, model: str):
        self.client = client
        self.model = model

    def parse(self, system_prompt: str, user_prompt: str, schema):
        """The API needs an object at the schema root, so the model or union is wrapped and unwrapped here."""
        root = create_model("Root", value=(schema, ...))
        completion = self.client.chat.completions.parse(model=self.model, messages=_messages(system_prompt, user_prompt), response_format=root)
        return completion.choices[0].message.parsed.value

    def text(self, system_prompt: str, user_prompt: str) -> str:
        completion = self.client.chat.completions.create(model=self.model, messages=_messages(system_prompt, user_prompt))
        return completion.choices[0].message.content


def create_llm(dbutils) -> LLM:
    mlflow.openai.autolog()
    credential = ClientSecretCredential(
        tenant_id=AZURE.tenant_id,
        client_id=dbutils.secrets.get(scope=AZURE.secret_scope, key=AZURE.client_id_key),
        client_secret=dbutils.secrets.get(scope=AZURE.secret_scope, key=AZURE.client_secret_key),
    )
    client = AzureOpenAI(
        azure_ad_token_provider=get_bearer_token_provider(credential, AZURE.token_scope),
        azure_endpoint=AZURE.endpoint,
        api_version=AZURE.api_version,
    )
    return LLM(client, AZURE.model)
