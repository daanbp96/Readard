from pydantic import BaseModel

from backend.card import CardState
from backend.llm import LLM
from backend.steps.build_chart import Chart, build_chart, sort_rows
from backend.steps.interpret_question import ChartSettings, FollowUp, New, Reject, interpret_question
from backend.steps.run_sql import run_sql
from backend.steps.summarise_result import summarise_result
from backend.steps.write_sql import write_sql
from config.tables import Table, catalog


class Rejection(BaseModel):
    reason: str
    suggestion: str


class Answer(BaseModel):
    title: str
    table_name: str
    rows: list[dict]
    chart: Chart
    findings: str


class Orchestrator:
    def __init__(self, spark, llm: LLM, tables: dict[str, Table]):
        self.spark = spark
        self.llm = llm
        self.tables = tables
        self.cards: dict[str, CardState] = {}

    def reset(self, card_id: str) -> None:
        self.cards.pop(card_id, None)

    def answer(self, card_id: str, question: str) -> Answer | Rejection:
        card = self.cards.setdefault(card_id, CardState())
        intent = interpret_question(self.llm, catalog(self.tables), card, question)
        match intent:
            case Reject():
                return Rejection(reason=intent.reason, suggestion=intent.suggestion)
            case New():
                self._query(card, intent.table_name, intent.question)
            case FollowUp(needs_data=True):
                self._query(card, intent.table_name, intent.question, previous_sql=card.sql)
            case FollowUp(settings=ChartSettings()):
                self._restyle(card, intent.settings)
        card.table_name = intent.table_name
        card.history = (card.history + [intent.question])[-5:]
        chart = build_chart(card.chart, card.result)
        card.chart_type = chart.chart_type
        return Answer(
            title=intent.question,
            table_name=intent.table_name,
            rows=card.result.rows,
            chart=chart,
            findings=card.findings,
        )

    def _query(self, card: CardState, table_name: str, question: str, previous_sql: str | None = None) -> None:
        plan = write_sql(self.llm, self.tables[table_name].text, question, previous_sql)
        result = run_sql(self.spark, plan.sql)
        card.sql, card.chart, card.result = plan.sql, plan.chart, result
        card.findings = summarise_result(self.llm, question, list(result.spark_types), result.rows, result.truncated)

    def _restyle(self, card: CardState, settings: ChartSettings) -> None:
        if settings.type:
            card.chart.type = settings.type
        if settings.sort:
            card.result.rows = sort_rows(card.result.rows, card.chart.y, descending=settings.sort == "desc")
