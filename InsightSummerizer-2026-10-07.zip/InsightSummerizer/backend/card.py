from pydantic import BaseModel

from backend.steps.run_sql import Result
from backend.steps.write_sql import ChartSpec


class CardState(BaseModel):
    table_name: str | None = None
    history: list[str] = []
    sql: str | None = None
    result: Result | None = None
    chart: ChartSpec | None = None
    chart_type: str | None = None
    findings: str = ""
